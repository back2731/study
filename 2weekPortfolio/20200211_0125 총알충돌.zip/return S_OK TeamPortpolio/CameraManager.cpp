#include "stdafx.h"
#include "CameraManager.h"


CameraManager::CameraManager()
{
}


CameraManager::~CameraManager()
{
}

HRESULT CameraManager::Init()
{
	return S_OK;
}

void CameraManager::Release()
{
}

void CameraManager::Update()
{
}

void CameraManager::Render(HDC hdc)
{
}
