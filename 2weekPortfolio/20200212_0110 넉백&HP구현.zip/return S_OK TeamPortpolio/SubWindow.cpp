#include "stdafx.h"
#include "SubWindow.h"
#include "gameNode.h"
#include "MapToolScene.h"

POINT SubWindow::ptMouse = POINT{ 0,0 };
CTRL SubWindow::_currentCTRL = CTRL_DRAW;

SubWindow::SubWindow()
{
	m_backBuffer = new image();
	m_backBuffer->init(SUBWINSIZEX, SUBWINSIZEY);
}

SubWindow::~SubWindow()
{
	SAFE_DELETE(m_backBuffer);
}

void SubWindow::init()
{
	CreateSubWindow();

	isActive = false;

	int tempX = 10;

	_btnDraw = CreateWindow("button", "Tile",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX, 0, 100, 20, hWnd, HMENU(0), m_hInstance, NULL);
	_btnEraser = CreateWindow("button", "Eraser",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX, 30, 100, 20, hWnd, HMENU(1), m_hInstance, NULL);
	_btnInit = CreateWindow("button", "Init",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX, 60, 100, 20, hWnd, HMENU(2), m_hInstance, NULL);
	_btnSave = CreateWindow("button", "Save",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX + 115, 0, 100, 20, hWnd, HMENU(3), m_hInstance, NULL);
	_btnLoad = CreateWindow("button", "Load",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX + 115, 30, 100, 20, hWnd, HMENU(4), m_hInstance, NULL);
	_btnMain = CreateWindow("button", "MainMenu",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX + 115, 60, 100, 20, hWnd, HMENU(8), m_hInstance, NULL);
	_btnN1 = CreateWindow("button", "Blocks",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX , 135, 70, 25, hWnd, HMENU(5), m_hInstance, NULL);
	_btnN2 = CreateWindow("button", "MapTiles",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX + 75, 135, 70, 25, hWnd, HMENU(6), m_hInstance, NULL);
	_btnN3 = CreateWindow("button", "Others",
		//�ڽ����� �����ϸ� ���ʿ� �������
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		tempX + 150, 135, 70, 25, hWnd, HMENU(7), m_hInstance, NULL);

	clickFrame = { 0,0 };
	clickIndex = 0;

}

void SubWindow::release()
{
}

void SubWindow::update()
{
	if (currentScene != NULL)
	{
		currentScene->update();
	}
}

void SubWindow::render()
{
	HDC hdc = GetDC(hWnd);
	PatBlt(m_backBuffer->getMemDC(), 0, 0, SUBWINSIZEX, SUBWINSIZEY, WHITENESS);

	if (currentScene != NULL)
	{
		currentScene->render(m_backBuffer->getMemDC());
	}
	m_backBuffer->render(hdc);
	ReleaseDC(hWnd, hdc);
}

void SubWindow::SetScene(gameNode * scene)
{
	currentScene = scene;
	currentScene->init();
}

LRESULT SubWindow::WndLogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_MOUSEMOVE:

		SUBWIN->SetIsActive(true);
		ptMouse.x = LOWORD(lParam);
		ptMouse.y = HIWORD(lParam);
		break;
		/*case WM_PAINT:
		{


		}
		break;*/
	case  WM_COMMAND:

		switch (LOWORD(wParam))
		{
		default:
			switch (LOWORD(wParam))
			{
			case CTRL_DRAW:
			case CTRL_ERASER:
				_currentCTRL = (CTRL)(LOWORD(wParam));
				break;

			case CTRL_INIT:
				SUBWIN->GetIsoMap()->init();
				break;
			case CTRL_SAVE:
				SUBWIN->GetIsoMap()->Save();
				break;
			case CTRL_LOAD:
				SUBWIN->GetIsoMap()->Load();
				break;
			case CTRL_NUM1:
			case CTRL_NUM2:
			case CTRL_NUM3:
				SUBWIN->SetFrameIndex(LOWORD(wParam) - 5);
				break;
			case CTRL_MAIN:
				SCENEMANAGER->changeScene("MainMenu");
				break;
			}
			break;
		}
		break;

	case WM_KEYDOWN:

		switch (wParam)
		{
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		}
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void SubWindow::CreateSubWindow()
{
	//�α� ������ ����
	int x, y, cx, cy;
	WNDCLASS wc;
	RECT rc;

	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc = (WNDPROC)SubWindow::WndLogProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = GetModuleHandle(NULL);
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = "sub";
	RegisterClass(&wc);
	//�θ� ������ �����ʿ� ��ġ ����.
	RECT rcWin;
	GetWindowRect(m_hWnd, &rcWin);

	cx = SUBWINSIZEX;
	cy = SUBWINSIZEY;
	x = rcWin.right;
	y = rcWin.top;

	rc.left = 0;
	rc.top = 0;
	rc.right = cx;
	rc.bottom = cy;

	HWND hParenthWnd = NULL;
	HINSTANCE hInst = NULL;

	hParenthWnd = m_hWnd;
	hInst = GetModuleHandle(NULL);

	hWnd = CreateWindow("sub", "sub",
		WS_POPUP | WS_CAPTION | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
		x, y, cx, cy, hParenthWnd, NULL, hInst, NULL);

	AdjustWindowRect(&rc, WINSTYLE, FALSE);

	SetWindowPos(hWnd, NULL, x, y, (rc.right - rc.left), (rc.bottom - rc.top), SWP_NOZORDER);

	ShowWindow(hWnd, SW_SHOW);
}