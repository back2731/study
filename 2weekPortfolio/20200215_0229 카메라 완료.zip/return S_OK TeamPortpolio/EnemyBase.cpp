#include "stdafx.h"
#include "EnemyBase.h"


EnemyBase::EnemyBase()
{
}


EnemyBase::~EnemyBase()
{
}

HRESULT EnemyBase::Init(POINT position)
{
	return S_OK;
}

void EnemyBase::Release()
{
}

void EnemyBase::Update()
{
}

void EnemyBase::Render(HDC hdc)
{
}
