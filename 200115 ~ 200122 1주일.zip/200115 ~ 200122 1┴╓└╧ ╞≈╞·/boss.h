#pragma once
class boss
{
public:
	boss();
	~boss();
};

