#pragma once
class playerCommonBullet
{
};

