#pragma once
#include "singletonBase.h"
#include "gameNode.h"
#include "redMinion.h"
#include "bulletManager.h"
#include "player.h"	

#define BULLETMANAGER		bulletManager::getSingleton()
#define PLAYER				player::getSingleton()

class enemyManager : public gameNode, public singletonBase<enemyManager>
{
private:

	typedef vector<redMinion*> vRedMinion;
	typedef vector<redMinion*>::iterator viRedMinion;

private:

	vRedMinion	m_vRedMinion;
	viRedMinion	m_viRedMinion;

	redMinion* m_redMinion;

	float rectX;
	float rectY;

public:
	enemyManager();
	~enemyManager();

	HRESULT init();
	void release();
	void update();
	void render();


	void redMinionUpdate();
	void redMinionRender();
	void setRedMinion();
	void redMinionBulletFire();

	vRedMinion getVMinion() { return m_vRedMinion; }
	viRedMinion	getViMinion() { return m_viRedMinion; }

	void deleteEnemy(int num);
};

