#include "stdafx.h"
#include "enemyBase.h"


enemyBase::enemyBase()
{
}


enemyBase::~enemyBase()
{
}

HRESULT enemyBase::init(const char * imageName, POINT position)
{
	return S_OK;
}

void enemyBase::release()
{
}

void enemyBase::update()
{
}

void enemyBase::render()
{

}

void enemyBase::draw()
{

}

void enemyBase::move()
{
}

void enemyBase::leftAnimation()
{

}

void enemyBase::rightAnimation()
{

}

void enemyBase::idleAnimation()
{

}
