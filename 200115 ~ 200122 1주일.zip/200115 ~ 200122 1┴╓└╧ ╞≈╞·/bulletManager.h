#pragma once
#include "singletonBase.h"
#include "gameNode.h"
#include "enemyManager.h"
#include "player.h"	

#define ENEMYMANAGER		enemyManager::getSingleton()
#define PLAYER				player::getSingleton()
struct tagCannon
{
	POINT center;
	POINT cannonEnd;
	int cannon;
	float angle;
};

class bulletManager : public gameNode, public singletonBase<bulletManager>
{
private:
	vector<bulletInfo> vPlayerCommonBullet;
	vector<bulletInfo>::iterator viPlayerCommonBullet;

	vector<bulletInfo> vRedMinionBullet;
	vector<bulletInfo>::iterator viRedMinionBullet;
	bulletInfo playerCommonBullet;

	bulletInfo redMinionBullet;
	tagCannon redMinionCannon;
	
	int bulletSpeed;

public:
	bulletManager();
	~bulletManager();

	HRESULT init();
	void release();
	void update();
	void render();

	void playerCommonBulletfire(float x, float y);
	void playerCommonBulletMove();
	void playerCommonBulletRender();
	void playerCommonBulletCollision();

	void redMinionBulletfire(float x, float y);
	void redMinionBulletMove();
	void redMinionBulletRender();

	vector<bulletInfo> getPlayerCommonBulletVector() { return vPlayerCommonBullet; }
};

