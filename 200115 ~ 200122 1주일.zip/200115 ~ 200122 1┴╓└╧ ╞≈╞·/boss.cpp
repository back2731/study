#include "stdafx.h"
#include "boss.h"


boss::boss()
{
}


boss::~boss()
{
}
