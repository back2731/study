#pragma once
class enemy
{
public:
	enemy();
	~enemy();
};

