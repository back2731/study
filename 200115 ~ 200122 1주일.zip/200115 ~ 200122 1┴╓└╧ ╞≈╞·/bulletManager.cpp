#include "stdafx.h"
#include "bulletManager.h"

bulletManager::bulletManager()
{
}


bulletManager::~bulletManager()
{
}

HRESULT bulletManager::init()
{
	return S_OK;
}

void bulletManager::release()
{
}

void bulletManager::update()
{
	
}

void bulletManager::render()
{
}

void bulletManager::playerCommonBulletfire(float x, float y)
{
	playerCommonBullet = OBJECTPOOL->getBullet();
	
	playerCommonBullet.bulletImage = IMAGEMANAGER->findImage("playerCommonBullet");
	playerCommonBullet.speed = 15.0f;
	playerCommonBullet.x = x;
	playerCommonBullet.y = y;
	playerCommonBullet.rc = RectMakeCenter(playerCommonBullet.x, 
										   playerCommonBullet.y,
										   playerCommonBullet.bulletImage->getWidth(),
										   playerCommonBullet.bulletImage->getHeight());
	vPlayerCommonBullet.push_back(playerCommonBullet);
}

void bulletManager::playerCommonBulletMove()
{
	for (viPlayerCommonBullet = vPlayerCommonBullet.begin(); viPlayerCommonBullet != vPlayerCommonBullet.end();)
	{
		viPlayerCommonBullet->y -= viPlayerCommonBullet->speed;
		viPlayerCommonBullet->rc = RectMakeCenter(viPlayerCommonBullet->x, viPlayerCommonBullet->y,
			viPlayerCommonBullet->bulletImage->getWidth(), viPlayerCommonBullet->bulletImage->getHeight());


		if (0 >= viPlayerCommonBullet->rc.bottom)
		{
			playerCommonBullet = { 0, };
			OBJECTPOOL->setBulletVector(playerCommonBullet);
			viPlayerCommonBullet = vPlayerCommonBullet.erase(viPlayerCommonBullet);
		}
		else ++viPlayerCommonBullet;
	}
}

void bulletManager::playerCommonBulletRender()
{
	for (viPlayerCommonBullet = vPlayerCommonBullet.begin(); viPlayerCommonBullet != vPlayerCommonBullet.end(); ++viPlayerCommonBullet)
	{
		if (KEYMANAGER->isToggleKey(VK_TAB))
		{
			Rectangle(getMemDC(), viPlayerCommonBullet->rc.left, viPlayerCommonBullet->rc.top, viPlayerCommonBullet->rc.right, viPlayerCommonBullet->rc.bottom);
		}

		viPlayerCommonBullet->bulletImage->render(getMemDC(), viPlayerCommonBullet->rc.left, viPlayerCommonBullet->rc.top);
	}
}

void bulletManager::playerCommonBulletCollision()
{		
	//
	for (int i = 0; i < vPlayerCommonBullet.size(); i++)
	{

		for (int j = 0; j < ENEMYMANAGER->getVMinion().size(); j++)
		{
			RECT rc;

			if (IntersectRect(&rc, &vPlayerCommonBullet[i].rc, &ENEMYMANAGER->getVMinion()[j]->getRect()))
			{
				playerCommonBullet = { 0, };
				OBJECTPOOL->setBulletVector(playerCommonBullet);
				vPlayerCommonBullet.erase(vPlayerCommonBullet.begin() + i);
				ENEMYMANAGER->deleteEnemy(j);
				break;
			}
		}
	}
	//
}

void bulletManager::redMinionBulletfire(float x, float y)
{
	redMinionBullet = OBJECTPOOL->getBullet();
	redMinionCannon.center.x = x;
	redMinionCannon.center.y = y;
	redMinionCannon.cannon = 100;
	
	redMinionBullet.bulletImage = IMAGEMANAGER->findImage("redMinionBullet");
	redMinionBullet.speed = 8.0f;
	redMinionBullet.angle = redMinionCannon.angle;

	if (bulletSpeed % 1 == 0)		// �Ѿ˰� �Ÿ� ����
	{
		// �Ѿ� ����
		//redMinionCannon.angle -=0.05f;
		redMinionBullet.x = redMinionCannon.center.x;
		redMinionBullet.y = redMinionCannon.center.y;
		redMinionBullet.rc = RectMakeCenter(redMinionBullet.x,
			redMinionBullet.y,
			redMinionBullet.bulletImage->getWidth(),
			redMinionBullet.bulletImage->getHeight());
		//
	}
	vRedMinionBullet.push_back(redMinionBullet);


	redMinionCannon.cannonEnd.x = cosf(redMinionCannon.angle) * redMinionCannon.cannon + redMinionCannon.center.x;
	redMinionCannon.cannonEnd.y = -sinf(redMinionCannon.angle) * redMinionCannon.cannon + redMinionCannon.center.y;

}

void bulletManager::redMinionBulletMove()
{
	bulletSpeed++;

	if (bulletSpeed % 1 == 0)		// �Ѿ˹߻� ���� ����
	{
		redMinionCannon.angle -= 0.05f;
	}

	// �Ѿ� �߻�
	viRedMinionBullet = vRedMinionBullet.begin();
	for (viRedMinionBullet; viRedMinionBullet != vRedMinionBullet.end();)
	{
		
		//viRedMinionBullet->y += viRedMinionBullet->speed;
		
		viRedMinionBullet->x += cosf(viRedMinionBullet->angle) * viRedMinionBullet->speed;
		viRedMinionBullet->y += -sinf(viRedMinionBullet->angle) * viRedMinionBullet->speed;

		viRedMinionBullet->rc = RectMakeCenter(viRedMinionBullet->x,
			viRedMinionBullet->y, viRedMinionBullet->bulletImage->getWidth(),
			viRedMinionBullet->bulletImage->getHeight());
		
		if (150 >= viRedMinionBullet->rc.right || WINSIZEY - 50 <= viRedMinionBullet->rc.top ||
			WINSIZEX - 400 <= viRedMinionBullet->rc.left || 100 > viRedMinionBullet->rc.bottom)
		{
			redMinionBullet = { 0, };
			OBJECTPOOL->setBulletVector(redMinionBullet);
			viRedMinionBullet = vRedMinionBullet.erase(viRedMinionBullet);
		}
		else ++viRedMinionBullet;
	}
	
}

void bulletManager::redMinionBulletRender()
{
	for (viRedMinionBullet = vRedMinionBullet.begin(); viRedMinionBullet != vRedMinionBullet.end(); ++viRedMinionBullet)
	{
		if (KEYMANAGER->isToggleKey(VK_TAB))
		{
			Rectangle(getMemDC(), viRedMinionBullet->rc.left, viRedMinionBullet->rc.top, viRedMinionBullet->rc.right, viRedMinionBullet->rc.bottom);
		}

		viRedMinionBullet->bulletImage->render(getMemDC(), viRedMinionBullet->rc.left, viRedMinionBullet->rc.top);
	}

}
