#include "stdafx.h"
#include "enemyManager.h"

enemyManager::enemyManager()
{
}


enemyManager::~enemyManager()
{
}

HRESULT enemyManager::init()
{
	setRedMinion();
	return S_OK;
}

void enemyManager::release()
{
	SAFE_DELETE(m_redMinion);
}

void enemyManager::update()
{
	redMinionUpdate();
}

void enemyManager::render()
{
	redMinionRender();
}

void enemyManager::redMinionUpdate()
{
	for (m_viRedMinion = m_vRedMinion.begin(); m_viRedMinion != m_vRedMinion.end(); ++m_viRedMinion)
	{
		(*m_viRedMinion)->update();
	}	
	
	redMinionBulletFire();

	BULLETMANAGER->redMinionBulletMove();
}

void enemyManager::redMinionRender()
{

	for (m_viRedMinion = m_vRedMinion.begin(); m_viRedMinion != m_vRedMinion.end(); ++m_viRedMinion)
	{
		(*m_viRedMinion)->render();
	}
	BULLETMANAGER->redMinionBulletRender();
}

void enemyManager::setRedMinion()
{
	for (int i = 0; i < 2; i++)
	{
		m_redMinion = new redMinion;
		m_redMinion->init("redMinion", PointMake(200, 100+i*50));
		m_vRedMinion.push_back(m_redMinion);
	}
	for (int i = 2; i < 4; i++)
	{
		m_redMinion = new redMinion;
		m_redMinion->init("redMinion", PointMake(400, 100 + (i - 2) * 50));
		m_vRedMinion.push_back(m_redMinion);
	}
	for (int i = 4; i < 6; i++)
	{
		m_redMinion = new redMinion;
		m_redMinion->init("redMinion", PointMake(600, 100 + (i - 4) * 50));
		m_vRedMinion.push_back(m_redMinion);
	}

}

void enemyManager::redMinionBulletFire()
{
	for (m_viRedMinion = m_vRedMinion.begin(); m_viRedMinion != m_vRedMinion.end(); ++m_viRedMinion)
	{
		BULLETMANAGER->redMinionBulletfire((*m_viRedMinion)->getRedMinionX(), (*m_viRedMinion)->getRedMinionY());
	}
}

void enemyManager::deleteEnemy(int num)
{
	m_vRedMinion.erase(m_vRedMinion.begin() + num);
}
