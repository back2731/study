#include "stdafx.h"
#include "scene1.h"


scene1::scene1()
{
}


scene1::~scene1()
{
}

HRESULT scene1::init()
{

	IMAGEMANAGER->addImage("�糪1", "images/�糪1.bmp", WINSIZEX, WINSIZEY,true, RGB(255,0,255));

	return S_OK;
}

void scene1::release()
{
}

void scene1::update()
{
	if (KEYMANAGER->isOnceKeyDown('2'))
	{
		//��ü����
		SCENEMANAGER->changeScene("scene2");
	}
}

void scene1::render()
{
	IMAGEMANAGER->render("�糪1", getMemDC());
}
