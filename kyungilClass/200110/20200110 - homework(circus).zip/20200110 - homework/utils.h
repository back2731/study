#pragma once

#define PI		3.141592653
#define PI2		PI*2
namespace UTIL
{
	//�Ÿ�
	float getDistance(float startX, float startY, float endX, float endY);

	float getAngle(float x1, float y1, float x2, float y2);
}